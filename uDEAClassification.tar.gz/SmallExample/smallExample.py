from uDEA import *
from classifyUtilsParallel import *
import pickle
import multiprocessing

if __name__ == '__main__':

   # try to keep things from hanging
   multiprocessing.set_start_method("spawn")
   
   # Load or recalculate the first uDEA problem, 
   #   default saves new data if recalculated
   loadDataDEA = 0
   
   # Load or recalculate the initial clusters with k-Means,
   #   default saves new clusters if recalculated
   loadInitialCluster = 0
   
   # Load or recalculate the initial clusters with k-Means,
   #   default saves new clusters if recalculated
   loadFinalCluster = 0
   
   # The data for a small illustrative example
   X = [[1, 2, 1.2, 2, 4]]
   Y = [[2, 3, 1,   2, 2.8]]
   RX = {}
   RY = {}
   RX[0] = []
   RY[0] = []
   for i in range(len(X[0])):
      RX[0].append([0 for j in range(len(X[0]))])
      RX[0][i][i] = 1
      RY[0].append([0 for j in range(len(X[0]))])
      RY[0][i][i] = 1
   
   print("Calculating the total proximity")
   calcProximityVal, minSigma, stat, proxLowBnd, proxUpBnd, sigLst = \
      proximityToEquitableEfficiency(X,Y,RX,RY)
   pFile = open("./data/uDEAresults.dat","wb")
   pickle.dump(sigLst,pFile)
   pFile.close()

#   if loadInitialCluster == 0:
#      print("Searching for initial clusters")
#      cluster,prox = srchForInitialClusters(X,Y,sigLst,3)
#      totProx = 0
#      for p in prox:
#         totProx = totProx + prox[p]
#      print(' ')
#      print('--------------------------------')
#      print('The initial clusters from k-Means are')
#      print(cluster)
#      print('The poximity measures are')
#      print(prox)
#      print('The total proximity is '+str(totProx))
#      print('--------------------------------')
#      print(' ')
#      #graphDEAclusters(X,Y,cluster,sigLst,'./prostateFigs/initialClusters.png')
#      #pFile = open("./data/initialClusters.dat","wb")
#      #pickle.dump(cluster, pFile)
#      #pFile.close()
#      #pFile = open("./data/initialProx.dat","wb")
#      #pickle.dump(prox, pFile)
#      #pFile.close()
#   else:
#      if os.path.isfile('./data/initialClusters.dat'):
#         pFile = open("./data/initialClusters.dat","rb")
#         cluster = pickle.load(pFile)
#         pFile.close()
#         #graphDEAclusters(X,Y,cluster,sigLst,'./prostateFigs/TMPinitialClusters.png')
#      if os.path.isfile('./data/initialProx.dat'):
#         pFile = open("./data/initialProx.dat","rb")
#         prox = pickle.load(pFile)
#         pFile.close()
#   
#   if loadFinalCluster == 0:
#      cluster,prox = swapAndSeek(X,Y,cluster,prox,sigLst)
#      totProx = 0
#      for p in prox:
#         totProx = totProx + prox[p]
#      print(' ')
#      print('--------------------------------')
#      print('The final clusters from seek and swap are')
#      print(cluster)
#      print('The poximity measures are')
#      print(prox)
#      print('The total proximity is '+str(totProx))
#      print('--------------------------------')
#      print(' ')
#      graphDEAclusters(X,Y,cluster,sigLst,'./prostateFigs/finalClusters.png')
#      pFile = open("./data/finalClusters.dat","wb")
#      pickle.dump(cluster, pFile)
#      pFile.close()
#      pFile = open("./data/finalProx.dat","wb")
#      pickle.dump(prox, pFile)
#      pFile.close()
   #elif loadFinalCluster == 1:
   #   if os.path.isfile('./data/finalClusters.dat'):
   #      pFile = open("./data/finalClusters.dat","rb")
   #      cluster = pickle.load(pFile)
   #      pFile.close()
   #      graphDEAclusters(X,Y,cluster,sigLst,'./prostateFigs/finalClusters.png')
   #   if os.path.isfile('./data/finalProx.dat'):
   #      pFile = open("./data/finalProx.dat","rb")
   #      prox = pickle.load(pFile)
   #      pFile.close()
