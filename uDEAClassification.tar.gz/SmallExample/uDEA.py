from __future__ import division # safety with double division
from pyomo.environ import *
from pyomo.opt import SolverFactory
from pyomo.opt import SolverStatus, TerminationCondition
from copy import *
from classifyUtilsParallel import *
import numpy 
import os
import logging

# Calculate the Efficiency of iHat relative to data X and Y
# The data matrices X and Y are lists of lists (not numpy objects)
# The code returns the efficiency score and a failure status:
#    status = 0 -> no failure, i.e. success
#    status = 1 -> failed to reach optimality
#    status = 2 -> failed dimensional inegrity 
def calcEfficiency(X,Y,iHat):
   # grab sizes
   mX = len(X)
   nX = len(X[0])
   mY = len(Y)
   nY = len(Y[0])

   # check dimensional integrity
   if nX != nY:
      return 0,2 

   # Instantiate the abstract model
   M = AbstractModel()
   M.n = RangeSet(0,nY-1)
   M.mY = RangeSet(0,mY-1)
   M.mX = RangeSet(0,mX-1)
   M.lam = Var(M.n, within=NonNegativeReals)
   M.theta= Var(within=NonNegativeReals)

   # Define the objective
   def calcEff(M):
      return M.theta
   M.obj = Objective(rule=calcEff, sense=minimize)

   # Define the ouput constraints
   def ensureOutput(M,i):
      return sum(Y[i][j]*M.lam[j] for j in M.n) >= Y[i][iHat]
   M.outConst = Constraint(M.mY, rule = ensureOutput)

   # Define the input constraints
   def ensureInput(M,i):
      return sum(X[i][j]*M.lam[j] for j in M.n) <= X[i][iHat]*M.theta
   M.inConst = Constraint(M.mX, rule = ensureInput)
   
   # Normalize the weights
   def ensureReturnToScale(M):
      return sum(M.lam[j] for j in M.n) == 1
   M.returnToScale = Constraint(rule=ensureReturnToScale)

   # Create the concrete model and solve
   instance = M.create_instance()
   Opt = SolverFactory("gurobi")
   Soln = Opt.solve(instance)
   instance.solutions.load_from(Soln)
   if str(TerminationCondition.optimal) == "optimal":
      return value(instance.obj),0 
   else:
      return 0,1


def uDEA2uLP(X,Y,RX,RY,iHat):
   # keep data sacrosinct
   Xtmp = deepcopy(X)
   Ytmp = deepcopy(Y)
   RXtmp = deepcopy(RX)
   RYtmp = deepcopy(RY)
   # Instantiate A, b, c, and R for the robust LP
   A = []
   Aeq = []
   b = []
   beq = []
   c = []
   R = {}
   # Get some sizes
   mX = len(Xtmp)
   mY = len(Ytmp)
   nX = len(Xtmp[0])
   nY = len(Ytmp[0])
   mRX = len(RXtmp)
   mRY = len(RYtmp)
   if nX == nY and mRX == mX and mRY == mY:
      n = nX
   else:
      return A, b, c, R, 1
   # Add input data to A 
   for i in range(mX):
      v = Xtmp[i]
      v.extend([0, -Xtmp[i][iHat]])
      A.append(v)
      b.append(0)
      Rmat = []
      for row in RXtmp[i]:
         v = row
         v.extend([0, -row[iHat]])
         Rmat.append(v)
      R[i] = Rmat
   # Add the output data to A
   for i in range(mY):
      v = [-a for a in Ytmp[i]]
      v.extend([Ytmp[i][iHat], 0])
      A.append(v)
      b.append(0)
      Rmat = []
      for row in RYtmp[i]:
         v = [-a for a in row]
         v.extend([row[iHat], 0])
         Rmat.append(v)
      R[i+mRX] = Rmat
   # Add equality to normalize weights as two inequalities
   v = [1 for i in range(n)]
   v.extend([0, 0])
   Aeq.append(v)
   beq.append(1)
   # Add equality constraint to ensure nonscaling of
   # of outputs as two inequalities
   v = [0 for i in range(n)]
   v.extend([1,0])
   Aeq.append(v)
   beq.append(1)
   # create objective
   c = [0 for i in range(n)]
   c.extend([0,1])

   return A,b,Aeq,beq,c,R,0

def solveRobustLP(A,b,Aeq,beq,c,R):
   Rmat = []      # an aggregated matrix stacking the R matrices
   Rindx = [0]    # an array listing indices of Rmat
   for k in range(len(R)):
      Rindx.append(Rindx[len(Rindx)-1] + len(R[k]))
      for row in R[k]:
         Rmat.append(row)

   M = AbstractModel()

   M.n = RangeSet(0,len(A[0])-1)
   M.m = RangeSet(0,len(A)-1)
   M.mEq = RangeSet(0,len(Aeq)-1)
   M.p = RangeSet(0,len(Rmat)-1)
   M.x = Var(M.n, within=NonNegativeReals)
   M.v = Var(M.m, within=NonNegativeReals)
   M.u = Var(M.p, within=Reals)
   
   def calcObj(M):
      return sum(c[i]*M.x[i] for i in M.n)
   M.linObj = Objective(rule=calcObj, sense=minimize)
   
   def calcLinConst(M,i):
      return sum(A[i][j]*M.x[j] for j in M.n) + M.v[i] <= b[i]
   M.linConst= Constraint(M.m, rule=calcLinConst)
   
   def equateRobust(M,i):
      return sum(Rmat[i][j]*M.x[j] for j in M.n) - M.u[i] == 0
   M.rbstBal = Constraint(M.p, rule=equateRobust)
   
   def enforceRobust(M,i):
         return sum(M.u[k]*M.u[k] for k in M.p if k >= Rindx[i] and k <= (Rindx[i+1]-1)) \
                - M.v[i]*M.v[i] <= 0
   M.socpConst = Constraint(M.m, rule=enforceRobust)

   def enforceEq(M,i):
      return sum(Aeq[i][j]*M.x[j] for j in M.n) == beq[i]
   M.eqConst = Constraint(M.mEq, rule=enforceEq)
   
   instance = M.create_instance()
   Opt = SolverFactory("gurobi")
   convTol = 10**(-9)
   maxAllowedTol = 10**(-5)
   while convTol < maxAllowedTol:
      Opt.options['BarQCPConvTol'] = convTol
      try:
         Soln = Opt.solve(instance)
         instance.solutions.load_from(Soln)
         if str(TerminationCondition.optimal) == "optimal":
            # adjusted to return perturbation vector (to create adjusted data) on 5/20/2023
            #return value(instance.linObj), 0
            dataAdjust = [value(instance.u[k]) for k in range(len(Rmat))]
            return value(instance.linObj), dataAdjust, 0
         else:
            convTol = convTol*10
      except:
         convTol = convTol*10
   return 0,0,1

def calcDiff(A,b,Aeq,beq,c,R,sigma,ds):
   tmpR = {} # R scaled by sigma
   for k in range(len(R)):
      tmpMat = []
      for row in R[k]:
         tmpMat.append([sigma[k]*a for a in row])
      tmpR[k] = tmpMat
   v1,dataAdjust,stat1 = solveRobustLP(A,b,Aeq,beq,c,tmpR)
   gradient = []
   stat = 0 # assume success in this case
   # create the R matrices to calculate the finite difference
   for k in range(len(R)):
      tmpRds = deepcopy(tmpR)
      tmpMat = []
      for row in R[k]:
         tmpMat.append([(sigma[k]+ds)*a for a in row])
      tmpRds[k] = tmpMat
      v2,dataAdjust,stat2 = solveRobustLP(A,b,Aeq,beq,c,tmpRds)
      if stat1 == 0 and stat2 == 0:
         gradient.extend([(v2-v1)/ds])
      else:
         stat = 1
   if stat == 0:
      return gradient,0
   else:
      return 0,1

# This function can be altered to skew the amount of
# uncertainty by the R mats, but we don't do so here
def calcAmountUnc(sigma):
   return numpy.linalg.norm(numpy.array(sigma),ord=2)

def calcDirDer(grad, sigma, R):
   M = AbstractModel()
   M.n = RangeSet(0, len(grad)-1)
   M.d = Var(M.n, within=Reals)
   def calcDer(M):
      return sum(M.d[i]*sigma[i]*(numpy.linalg.norm(numpy.array(R[i]), ord=2))**2 \
                 for i in R)
   M.dirDer = Objective(rule=calcDer, sense=minimize)
   def ensureOrtho(M):
      return (0, sum(M.d[i]*grad[i] for i in M.n), 0)
      #return sum(M.d[i]*grad[i] for i in M.n) == 0
   M.ortho = Constraint(rule=ensureOrtho)
   def ensureBound(M):
      return sum(M.d[i]*M.d[i] for i in M.n) <= 1
   M.boundDir = Constraint(rule=ensureBound)
   instance = M.create_instance()
   Opt = SolverFactory("gurobi")
   convTol = 10**(-9)
   maxAllowedTol = 10**(-5)
   while convTol < maxAllowedTol:
      Opt.options['BarQCPConvTol'] = convTol
      Soln = Opt.solve(instance)
      instance.solutions.load_from(Soln)
      if str(TerminationCondition.optimal) == "optimal":
         return [value(instance.d[i]) for i in instance.n], value(instance.dirDer), 0
      else:
         convTol = convTol*10
   return [0 for i in instance.n], 1 # return d=0 if not optimal

def calcDirToSrch(gradT, sigma):
   M = AbstractModel()
   M.n = RangeSet(0,len(gradT)-1)
   M.d = Var(M.n, within=Reals)
   def calcDirT(M):
      return sum(M.d[i]*sigma[i] for i in M.n)
   M.dirT = Objective(rule=calcDirT, sense=minimize)
   def calcAngleT(M):
      return sum(M.d[i]*gradT[i] for i in M.n) >= 0
   M.angleT = Constraint(rule=calcAngleT)
   def calcNormT(M):
      return sum(M.d[i]*M.d[i] for i in M.n) <= 1
   M.normT = Constraint(rule=calcNormT)
   instance = M.create_instance()
   Opt = SolverFactory("gurobi")
   convTol = 10**(-9)
   Opt.options['BarQCPConvTol'] = convTol
   Soln = Opt.solve(instance)
   instance.solutions.load_from(Soln)
   if str(TerminationCondition.optimal) == "optimal":
      return [value(instance.d[i]) for i in instance.n], value(instance.dirT), 0
   else:
      return [0 for i in instance.n], 0, 1  # we failed to get a solve

def calcRobustEff(A,b,Aeq,beq,c,sigma,R):
   tmpR = {} # R scaled by sigma
   for k in range(len(R)):
      tmpMat = []
      for row in R[k]:
         tmpMat.append([sigma[k]*a for a in row])
      tmpR[k] = tmpMat
   uncEffScore,dataAdjust,sUncEff = solveRobustLP(A,b,Aeq,beq,c,tmpR)
   return uncEffScore,dataAdjust,sUncEff

def srchToReduceUnc(A,b,Aeq,beq,c,sigma,R,d,effToMaintain, effTol,targetImprovement):
   #if effToMaintain >= effTol:    # we plan on converging in the next term or two
   #   tol = effTol/100            # amount of permissible degradation in efficiency
   #else:                          # the above gave occassional numerical problems at the last step
   tol = targetImprovement*0.2 # keep 80 percent of the efficiency gain
   lft = 0.0
   num = sum([sigma[i]*d[i]*numpy.linalg.norm(numpy.array(R[i]), ord=2) for i in range(len(d))])
   den = sum([d[i]*d[i]*numpy.linalg.norm(numpy.array(R[i]), ord=2) for i in range(len(d))])
   if abs(den) > 10**(-8):
      rght = -num/den
   else:
      return 0.0
   tmpSigma = [sum(tot) for tot in zip(sigma, [rght*dsig for dsig in d])] 
   tmpEffScore,tmpDataAdjust,stat = calcRobustEff(A,b,Aeq,beq,c,tmpSigma,R)
   if tmpEffScore < effToMaintain - tol:
      continueSearch = True
      while continueSearch:
         mid = (lft+rght)/2
         tmpSigma = [sum(tot) for tot in zip(sigma, [mid*dsig for dsig in d])] 
         tmpEffScore,tmpDataAdjust,stat = calcRobustEff(A,b,Aeq,beq,c,tmpSigma,R)
         if tmpEffScore < effToMaintain - tol:
            rght = mid
         else:
            if tmpEffScore <= effToMaintain:
               rght = mid
               continueSearch = False
            else:
               lft = mid
         # check to see if the interval has collapsed, need to terminate if so
         if abs(rght-lft) < 10**(-8):
            continueSearch = False
   return rght

def calcTotEff(ASys,bSys,AeqSys,beqSys,cSys,sigma,RSys):
   totEff = 0
   for s in range(len(ASys)):
      tmpEff,tmpDataAdjust,sEff = \
         calcRobustEff(ASys[s],bSys[s],AeqSys[s],beqSys[s],cSys[s],sigma,RSys[s])
      totEff = totEff + tmpEff
   return totEff

def calcGradTotEff(totEff,ASys,bSys,AeqSys,beqSys,cSys,sigmaBst,RSys):
   ds = 10**(-2)  # calculate gradient approximation with this
   gradTotEff = []
   for k in range(len(sigmaBst)):
      tmpSigma = deepcopy(sigmaBst)
      tmpSigma[k] = tmpSigma[k]-ds  #important to use the left-side
      tmpTotEff = calcTotEff(ASys,bSys,AeqSys,beqSys,cSys,tmpSigma,RSys)
      gradTotEff.append( (totEff - tmpTotEff)/ds )
   return gradTotEff

def srchForMinSigma(ASys,bSys,AeqSys,beqSys,cSys,sigmaMax,RSys,MplusN):
   eps = 10**(-3)
   sigmaBst = deepcopy(sigmaMax)  # Initialize what we return as optimal sigma
   totEff = calcTotEff(ASys,bSys,AeqSys,beqSys,cSys,sigmaBst,RSys)
   if totEff < len(ASys) - eps:  # We don't have a feasible sigma
      return sigmaBst,1 
   else: # We have a feasible sigma and search for an optimal sigma
      continueToTryAndReduceSigma = 1
      while continueToTryAndReduceSigma:
         gradTotEff = calcGradTotEff(totEff,ASys,bSys,AeqSys,beqSys,cSys,sigmaBst,RSys)
         dirToSrch, dirDerVal, dirStat = calcDirToSrch(gradTotEff, sigmaBst)
         if dirDerVal >= 0 or dirStat:
            continueToTryAndReduceSigma = False
         else:
            left = 0
            sqrtArg = dirDerVal**2 - (numpy.linalg.norm(numpy.array(sigmaBst),ord=2)**2 - \
                                      (1/sqrt(MplusN))*
                                      numpy.linalg.norm(numpy.array(sigmaMax),ord=2)**2 ) 
            if sqrtArg >= 0:
               right = -dirDerVal - sqrt(sqrtArg)
            else:
               right = left  # use this to terminate the search
            if left >= right:
                  continueToTryAndReduceSigma = False  # Something went wrong
            else: 
               tmpSigma = deepcopy(sigmaBst)
               tmpSigma = [tmpSigma[k] + (right*dirToSrch[k]) for k in range(len(tmpSigma))]
               tmpTotEffLft = deepcopy(totEff)
               tmpTotEffRght = calcTotEff(ASys,bSys,AeqSys,beqSys,cSys,tmpSigma,RSys)
               if tmpTotEffRght <= len(ASys) - eps:
                  continueSrchTotEff = True
                  while continueSrchTotEff:
                     mid = (left+right)/2
                     tmpSigma = deepcopy(sigmaBst)
                     tmpSigma = [tmpSigma[k] + (mid*dirToSrch[k]) for k in range(len(tmpSigma))]
                     tmpTotEffMid = calcTotEff(ASys,bSys,AeqSys,beqSys,cSys,tmpSigma,RSys)
                     if tmpTotEffMid < len(ASys) - eps:
                        right = mid
                        tmpTotEffRght = tmpTotEffMid
                     else:
                        left = mid
                        tmpTotEffLft = tmpTotEffMid
                     if abs(right-left) < eps*10**(-1):  # we are done
                        continueSrchTotEff = False
                        scalarToUse = (right - left)/2
               else:
                  scalarToUse = right
         if continueToTryAndReduceSigma:
            prevBst = calcAmountUnc(sigmaBst)
            sigmaBst = [sigmaBst[k] + scalarToUse*dirToSrch[k] for k in range(len(sigmaBst))]
            # Get the adjusted data vector for the best sigma - added 5/30/2023
            totEff = calcTotEff(ASys,bSys,AeqSys,beqSys,cSys,sigmaBst,RSys)
            #print("\tReduced uncertainty to "+str(calcAmountUnc(sigmaBst))+" "+str(prevBst))
            if abs(prevBst - calcAmountUnc(sigmaBst)) < 10**(-1)*eps:  # we are done
               continueToTryAndReduceSigma = False
      return sigmaBst,0
  
def uDEAnalysis(X,Y,iHat,RX,RY,A,b,Aeq,beq,c,R):
   # default tols
   ds = 10**(-1)             # calculate gradient of efficiency
   effTol = 0.995            # confirm efficiency
   numTargetedSteps = 10     # number of iterations to target
   itrBnd = 30               # iteration bound
   # flag to display output for debugging
   showOutput = 0
   # initialize sigma
   sigma = [0 for k in range(len(R))]  # initiate with no uncertainty
   # calculate nominal efficiency score
   effScore,sEff = calcEfficiency(X,Y,iHat)
   tmpDataAdjust = [0 for i in range(2*len(X[0]))]
   if effScore > effTol:
      return effScore, 0, sigma, tmpDataAdjust, 0 #efficiency score, amount of uncertainty, stat
   elif sEff != 0:
      return 0, 0, sigma, tmpDataAdjust, 1 #efficiency score, amount of uncertaint, stat
   # Set the targeted improvment to expidite calculations
   targetImprovement = (1-effScore)/numTargetedSteps
   #
   # Conduct search for improved efficiency
   #
   uncEffScore = deepcopy(effScore)
   itrCnt = 1
   while (uncEffScore < effTol) and (itrCnt <= itrBnd):
      # calculate the gradient
      grad,sGrad = calcDiff(A,b,Aeq,beq,c,R,sigma,ds)
      #print('\nsrch loop dont calc grad, stat = '+str(sGrad)+'\n')
      # calculate a step size - target an improvement of targetImprovement in efficiencey score
      if uncEffScore < 1-targetImprovement:
         stpSz = targetImprovement/(sum(grad[i]*grad[i] for i in range(len(grad))))
      else:
         stpSz = (1-uncEffScore)/(sum(grad[i]*grad[i] for i in range(len(grad))))
      # update sigma
      sigma = [sum(tot) for tot in zip(sigma, [stpSz*dsig for dsig in grad])] 
      # calculate updated efficiency
      uncEffScore,tmpDataAdjust,stat = calcRobustEff(A,b,Aeq,beq,c,sigma,R)
      # calculate the updated gradient
      grad,sGrad = calcDiff(A,b,Aeq,beq,c,R,sigma,ds)
      # if we get a gradient try to reduce magnitude of sigma
      # if not, then skip this step
      if sGrad == 0:
         # calculate direction to decrease uncertainty
         d, dirDer, sDirDer = calcDirDer(grad, sigma, R)
         # try to reduce the amount of uncertainty
         alpha = srchToReduceUnc(A,b,Aeq,beq,c,sigma,R,d,uncEffScore,effTol,targetImprovement)
         # update sigma
         sigma = [sum(tot) for tot in zip(sigma, [alpha*dsig for dsig in d])] 
         # calculate the state of efficiency and uncertainty
         amntUnc = calcAmountUnc(sigma)
         uncEffScore,tmpDataAdjust,stat = calcRobustEff(A,b,Aeq,beq,c,sigma,R)
      else:
         amntUnc = calcAmountUnc(sigma)

      if showOutput:
         print("Iteration "+str(itrCnt))
         print("\tEfficiency score is "+str(uncEffScore))
         print("\tAmount of uncertainty is "+str(amntUnc))
         #print("\t\tChanged uncertainty in 2nd search is "+str(amntUnc-potAmntUnc))
         print("\tsigma is "+str(sigma))
         #raw_input("paused")
         itrCnt = itrCnt + 1
   if uncEffScore < effTol:
      return uncEffScore, amntUnc, sigma, tmpDataAdjust, 1
   else:
      return uncEffScore, amntUnc, sigma, tmpDataAdjust, 0
    
def proximityToEquitableEfficiency(X,Y,RX,RY):
   # clear screen and turn off odd warnings
   logging.getLogger('pyomo.core').setLevel(logging.ERROR)
   #_=os.system('clear')
   # start some pretty output
   print(" ")
   print("Proximity to Equitable Efficiency")
   print("=================================")
   print(" ")
   print("Creating LP data for all DMUs ", end='')
   # instantiate data for study
   ASys = {}
   bSys = {}
   AeqSys = {}
   beqSys = {}
   cSys = {}
   RSys = {}
   sigmaMax = [0 for k in range(len(X)+len(Y))]     # assume no uncertainty at start
   sigmaMaxInd = [0 for k in range(len(X)+len(Y))]  # DMU providing max value
   sigmaList = {}                                   # List of sigmas
   for s in range(len(X[0])):
      ASys[s],bSys[s],AeqSys[s],beqSys[s],cSys[s],RSys[s],sConv = uDEA2uLP(X,Y,RX,RY,s)
   print("- done")
   print("Calculating sigma for each of the "+str(len(X[0]))+" DMUs")
   print("Done with: ", end='')
   for s in range(len(X[0])):
      robustEff,amntUnc,sigma,Rx,suDEA = \
         uDEAnalysis(X,Y,s,RX,RY,ASys[s],bSys[s],AeqSys[s],beqSys[s],cSys[s],RSys[s])
      sigmaList[s] = sigma
      # note: Rx is bad notation, not input x, but rather, Rx in general model
      # notation slowly tansistions to DEA input/output/X/Y below
      inRx = [Rx[i] for i in range(len(X[0]))]
      outRx = [Rx[len(X[0])+i] for i in range(len(X[0]))]
      # build a perturbation vector
      if sum(inRx) == 0:
         pertX = inRx
      else:
         pertX = [(sigma[0]*j)/sqrt(sum([i**2 for i in inRx])) for j in inRx]
      if sum(outRx) == 0:
         pertY = outRx
      else:
         pertY = [(sigma[1]*j)/sqrt(sum([i**2 for i in outRx])) for j in outRx]
      for k in range(len(X)+len(Y)):
         if sigma[k] > sigmaMax[k]:
            sigmaMax[k] = sigma[k]
            sigmaMaxInd[k] = s
      if ((s+1) % 10) == 0:
         if suDEA == 0:
            print("\n\t"+str(s+1)+",", end='')
         else:
            print("\n\t"+str(s+1)+"-fail,", end='')
      else:
         if suDEA == 0:
            print(' ')
            print(str(s+1)+"("+str(sigma[0])+","+str(sigma[1])+"),\n", end='')
            print("Orig Input Data\n")
            print("\t"+str(X[0])+"\n")
            print("Selected Input Data\n")
            print("\t"+str([X[0][i] + pertX[i] for i in range(len(X[0]))])+"\n")
            if abs(sqrt(sum([i**2 for i in pertX])) - sigma[0]) < 0.001:
               print("Total Input Deviation = "+str(sigma[0]))
            #
            print("Orig Output Data\n")
            print("\t"+str(Y[0])+"\n")
            print("Selected Output Data\n")
            print("\t"+str([Y[0][i] + pertY[i] for i in range(len(Y[0]))])+"\n")
            if abs(sqrt(sum([i**2 for i in pertY])) - sigma[1]) < 0.001:
               print("Total Output Deviation = "+str(sigma[1]))
            print(' ')
            print("Total Deviation = "+str(sqrt(sum([i**2 for i in sigma]))))
            print("\n-----------------------")
            graphDEAclusters([X[0][i] for i in range(len(X[0]))], \
                             [Y[0][i] for i in range(len(Y[0]))], \
                             [X[0][i] + pertX[i] for i in range(len(X[0]))], \
                             [Y[0][i] + pertY[i] for i in range(len(Y[0]))],s, \
                             "./smallExampleFigs/adjustedDataDMU_"+str(s)+".png")
                             
         else:
            print(str(s+1)+"-fail,", end='')
   print(" ")

   # Update user about status
   if len(set(sigmaMaxInd)) == 1:
      optNormSigma = calcAmountUnc(sigmaMax)
      print("sigmaMax defined by "+str(sigmaMaxInd[0]))
      print("Theory implies: Proximity = "+str(optNormSigma))
      return optNormSigma, sigmaMax, sigmaMaxInd[0], optNormSigma, optNormSigma, sigmaList
   else:
      print("sigmaMax is not uniquely defined")
      bndUncUp = calcAmountUnc(sigmaMax)
      bndUncLow = bndUncUp/sqrt(len(X)+len(Y))
      print("Theory implies: "+str(bndUncLow)+" <= Proximity <= "+str(bndUncUp))
      print("\tSearching for min Proximity")
      # In this case we need to try and reduce sigma
      MplusN = len(X)+len(Y)
      minSigma,sMinSigma = srchForMinSigma(ASys,bSys,AeqSys,beqSys,cSys,sigmaMax,RSys,MplusN)
      print("\nComputed Proximity = "+str(calcAmountUnc(minSigma)))
      print("\nWith minSigma of "+str(minSigma))
      return calcAmountUnc(minSigma), minSigma, -1, bndUncLow, bndUncUp, sigmaList

