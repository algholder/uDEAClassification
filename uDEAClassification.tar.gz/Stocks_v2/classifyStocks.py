from uDEA import *
from classifyUtilsParallel import *
import pickle
import multiprocessing
import datetime as dt
import pandas as pd
import yfinance as yf
from pandas_datareader import data as pdr
import math

if __name__ == '__main__':

   # try to keep things from hanging
   multiprocessing.set_start_method("spawn")

   # Load or recalculate the first uDEA problem, 
   #   default saves new data if recalculated
   loadDataDEA = 0

   # Load or recalculate the initial clusters with k-Means,
   #   default saves new clusters if recalculated
   loadInitialCluster = 0

   # Load or recalculate the initial clusters with k-Means,
   #   default saves new clusters if recalculated
   loadFinalCluster = 0

   #
   # Begin Calculations
   # 

   if loadDataDEA == 0:
      DJsymb = ['MMM', 'AXP', 'AMGN', 'AAPL', 'BA', 'CAT', 'CVX', \
                'CSCO', 'KO', 'DIS', 'DOW', 'GS', 'HD', 'HON', 'IBM', \
                'INTC', 'JNJ', 'JPM', 'MCD', 'MRK', 'MSFT', 'NKE', \
                'PG', 'CRM', 'TRV', 'UNH', 'VZ', 'V', 'WBA', 'WMT']
      month = ['01','02','03','04','05','06','07','08','09','10','11','12']

      pStrt = [[yf.download([s], start = "2020-"+m+"-01", end = "2020-"+m+"-07").Close[0] for m in month] for s in DJsymb]
      pEnd  = [[yf.download([s], start = "2021-"+m+"-01", end = "2021-"+m+"-07").Close[0] for m in month] for s in DJsymb]
      rt = [[(pEnd[i][j] - pStrt[i][j]) / pStrt[i][j] for j in range(len(pStrt[0]))] for i in range(len(pStrt))]
      avgRet = [sum([rt[i][j] for j in range(len(pStrt[0]))]) / len(pStrt[0]) for i in range(len(pStrt))]
      numBelAvg = [len([j for j in range(len(pStrt[0])) if rt[i][j] < avgRet[i]]) for i in range(len(pStrt))]
      sumSqrs = [sum([(rt[i][j] - avgRet[i])**2 for j in range(len(pStrt[0])) if rt[i][j] < avgRet[i]]) \
                 for i in range(len(pStrt))]
      semiVar = [math.sqrt(sumSqrs[i] / (numBelAvg[i]-1)) for i in range(len(pStrt))]
      X = [semiVar]
      Y = [avgRet]
      RX = {}
      RY = {}
      RX[0] = []
      RY[0] = []
      for i in range(len(X[0])):
         RX[0].append([0 for j in range(len(X[0]))])
         RX[0][i][i] = 1
         RY[0].append([0 for j in range(len(X[0]))])
         RY[0][i][i] = 1
      pFile = open("./data/XStockDat.dat","wb")
      pickle.dump(X,pFile)
      pFile.close()
      pFile = open("./data/YStockDat.dat","wb")
      pickle.dump(Y,pFile)
      pFile.close()
      print("Calculating the total proximity")
      calcProximityVal, minSigma, stat, proxLowBnd, proxUpBnd, sigLst = \
         proximityToEquitableEfficiency(X,Y,RX,RY)
      pFile = open("./data/uDEAresultsStocks.dat","wb")
      pickle.dump(sigLst,pFile)
      pFile.close()
   else:
      if os.path.isfile('./data/uDEAresultsStocks.dat'):
         pFile = open("./data/uDEAresultsStocks.dat","rb")
         sigLst = pickle.load(pFile)
         pFile.close()
      if os.path.isfile('./data/XStockDat.dat'):
         pFile = open("./data/XStockDat.dat","rb")
         X = pickle.load(pFile)
         pFile.close()
      if os.path.isfile('./data/YStockDat.dat'):
         pFile = open("./data/YStockDat.dat","rb")
         Y = pickle.load(pFile)
         pFile.close()

   # Added in response to 2nd review, 5/31/2023
   #
   # Create some comparative clusters
   #
   # First, k-means on DEA data
   #
   # create DMUdata
   DMUdataLst = {}
   for i in range(len(X[0])):
      DMUdataLst[i] = [X[0][i], Y[0][i]]
   print("Calculating clusters from p-Means with DMU data")
   cluster,prox = clusterKMeans(DMUdataLst, 3, 'radial')
   print(' ')
   print('The clusters are')
   print(cluster)
   print(' ')
   graphDEAclusters(X,Y,cluster,sigLst,'./stockFigs/DMUdataClusters.png')
   #
   # First, k-means on DEA data
   #
   print("Calculating clusters from p-Means with sigmas")
   cluster,prox = clusterKMeans(sigLst, 3, 'radial')
   print(' ')
   print('The clusters are')
   print(cluster)
   print(' ')
   graphDEAclusters(X,Y,cluster,sigLst,'./stockFigs/sigmaUnrestrictedClusters.png')
   #
   # End added code
   #

   if loadInitialCluster == 0:
      print("Searching for initial clusters")
      cluster,prox = srchForInitialClusters(X,Y,sigLst,3)
      totProx = 0
      for p in prox:
         totProx = totProx + prox[p]
      print(' ')
      print('--------------------------------')
      print('The initial clusters from k-Means are')
      print(cluster)
      print('The poximity measures are')
      print(prox)
      print('The total proximity is '+str(totProx))
      print('--------------------------------')
      print(' ')
      graphDEAclusters(X,Y,cluster,sigLst,'./stockFigs/initialClusters.png')
      pFile = open("./data/initialClustersStocks.dat","wb")
      pickle.dump(cluster, pFile)
      pFile.close()
      pFile = open("./data/initialProxStocks.dat","wb")
      pickle.dump(prox, pFile)
      pFile.close()
   else:
      if os.path.isfile('./data/initialClustersStocks.dat'):
         pFile = open("./data/initialClustersStocks.dat","rb")
         cluster = pickle.load(pFile)
         pFile.close()
      if os.path.isfile('./data/initialProxStocks.dat'):
         pFile = open("./data/initialProxStocks.dat","rb")
         prox = pickle.load(pFile)
         pFile.close()
      if os.path.isfile('./data/XStockDat.dat'):
         pFile = open("./data/XStockDat.dat","rb")
         X = pickle.load(pFile)
         pFile.close()
      if os.path.isfile('./data/YStockDat.dat'):
         pFile = open("./data/YStockDat.dat","rb")
         Y = pickle.load(pFile)
         pFile.close()

   if loadFinalCluster == 0:
      cluster,prox = swapAndSeek(X,Y,cluster,prox,sigLst)
      totProx = 0
      for p in prox:
         totProx = totProx + prox[p]
      print(' ')
      print('--------------------------------')
      print('The final clusters from seek and swap are')
      print(cluster)
      print('The poximity measures are')
      print(prox)
      print('The total proximity is '+str(totProx))
      print('--------------------------------')
      print(' ')
      graphDEAclusters(X,Y,cluster,sigLst,'./stockFigs/finalClusters.png')
      pFile = open("./data/finalClustersStocks.dat","wb")
      pickle.dump(cluster, pFile)
      pFile.close()
      pFile = open("./data/finalProxStocks.dat","wb")
      pickle.dump(prox, pFile)
      pFile.close()
   elif loadFinalCluster == 1:
      if os.path.isfile('./data/finalClustersStocks.dat'):
         pFile = open("./data/finalClustersStocks.dat","rb")
         cluster = pickle.load(pFile)
         pFile.close()
      if os.path.isfile('./data/XStockDat.dat'):
         pFile = open("./data/XStockDat.dat","rb")
         X = pickle.load(pFile)
         pFile.close()
      if os.path.isfile('./data/YStockDat.dat'):
         pFile = open("./data/YStockDat.dat","rb")
         Y = pickle.load(pFile)
         pFile.close()
      graphDEAclusters(X,Y,cluster,sigLst,'./stockFigs/finalClusters.png')
