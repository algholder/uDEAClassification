from uDEA import *
from classifyUtilsParallel import *
import pickle
import multiprocessing

if __name__ == '__main__':

   # try to keep things from hanging
   multiprocessing.set_start_method("spawn")
   
   # Load or recalculate the first uDEA problem, 
   #   default saves new data if recalculated
   loadDataDEA = 0
   
   # Load or recalculate the initial clusters with k-Means,
   #   default saves new clusters if recalculated
   loadInitialCluster = 0
   
   # Load or recalculate the initial clusters with k-Means,
   #   default saves new clusters if recalculated
   loadFinalCluster = 0
   
   # The data for the full prostate problem
   RX = {}
   RY = {}
   RX[0] = []
   RY[0] = []
   for i in range(42):
      RX[0].append([0 for j in range(42)])
      RX[0][i][i] = 1
      RY[0].append([0 for j in range(42)])
      RY[0][i][i] = 1
   
   X = [[61.418, 62.478, 62.805, 61.369, 60.744, 63.714, 62.779, 61.745, \
         62.560, 63.457, 61.314, 61.730, 61.610, 62.160, 60.362, 61.934, \
         62.192, 61.403, 60.173, 62.562, 60.710, 60.502, 63.648, 63.870, \
         63.644, 63.763, 61.192, 63.545, 62.181, 62.746, 62.019, 61.572, \
         62.603, 61.522, 59.567, 64.804, 61.854, 61.593, 63.570, 61.658, \
         62.529, 60.056]]
   Y = [[71.625, 71.025, 71.275, 71.225, 71.675, 71.825, 71.675, 71.775, \
         71.775, 71.575, 71.525, 71.575, 71.525, 71.675, 71.725, 71.625, \
         71.475, 71.475, 71.825, 71.725, 71.325, 71.375, 71.975, 72.025, \
         71.875, 72.075, 72.125, 71.325, 71.025, 71.425, 72.075, 70.875, \
         71.625, 71.425, 71.725, 72.125, 72.025, 71.775, 71.425, 71.525, \
         71.175, 71.575]]
   
#   RX = {}
#   RY = {}
#   RX[0] = []
#   RY[0] = []
#   for i in range(16):
#      RX[0].append([0 for j in range(16)])
#      RX[0][i][i] = 1
#      RY[0].append([0 for j in range(16)])
#      RY[0][i][i] = 1
#   
#   X = [[61.418, 62.478, 62.805, 61.369, 60.744, 63.714, 62.779, 61.745, \
#         62.560, 63.457, 61.314, 61.730, 61.610, 62.160, 60.362, 61.934 ]]
#   Y = [[71.625, 71.025, 71.275, 71.225, 71.675, 71.825, 71.675, 71.775, \
#         71.775, 71.575, 71.525, 71.575, 71.525, 71.675, 71.725, 71.625 ]]
   
   if loadDataDEA == 1:
      if os.path.isfile('./data/uDEAresults.dat'):
         pFile = open("./data/uDEAresults.dat","rb")
         sigLst = pickle.load(pFile)
         pFile.close()
   else:
      print("Calculating the total proximity")
      calcProximityVal, minSigma, stat, proxLowBnd, proxUpBnd, sigLst = \
         proximityToEquitableEfficiency(X,Y,RX,RY)
      pFile = open("./data/uDEAresults.dat","wb")
      pickle.dump(sigLst,pFile)
      pFile.close()

   # Added in response to 2nd review, 5/31/2023
   #
   # Create some comparative clusters
   #
   # First, k-means on DEA data
   #
   # create DMUdata
   DMUdataLst = {}
   for i in range(len(X[0])):
      DMUdataLst[i] = [X[0][i], Y[0][i]]
   print("Calculating clusters from p-Means with DMU data")
   cluster,prox = clusterKMeans(DMUdataLst, 3, 'radial')
   print(' ')
   print('The clusters are')
   print(cluster)
   print(' ')
   graphDEAclusters(X,Y,cluster,sigLst,'./prostateFigs/DMUdataClusters.png')
   #
   # First, k-means on DEA data
   #
   print("Calculating clusters from p-Means with sigmas")
   cluster,prox = clusterKMeans(sigLst, 3, 'radial')
   print(' ')
   print('The clusters are')
   print(cluster)
   print(' ')
   graphDEAclusters(X,Y,cluster,sigLst,'./prostateFigs/sigmaUnrestrictedClusters.png')
   #
   # End added code
   #
   
   if loadInitialCluster == 0:
      print("Searching for initial clusters")
      cluster,prox = srchForInitialClusters(X,Y,sigLst,3)
      totProx = 0
      for p in prox:
         totProx = totProx + prox[p]
      print(' ')
      print('--------------------------------')
      print('The initial clusters from k-Means are')
      print(cluster)
      print('The poximity measures are')
      print(prox)
      print('The total proximity is '+str(totProx))
      print('--------------------------------')
      print(' ')
      #graphDEAclusters(X,Y,cluster,sigLst,'./prostateFigs/initialClusters.png')
      #pFile = open("./data/initialClusters.dat","wb")
      #pickle.dump(cluster, pFile)
      #pFile.close()
      #pFile = open("./data/initialProx.dat","wb")
      #pickle.dump(prox, pFile)
      #pFile.close()
   else:
      if os.path.isfile('./data/initialClusters.dat'):
         pFile = open("./data/initialClusters.dat","rb")
         cluster = pickle.load(pFile)
         pFile.close()
         #graphDEAclusters(X,Y,cluster,sigLst,'./prostateFigs/TMPinitialClusters.png')
      if os.path.isfile('./data/initialProx.dat'):
         pFile = open("./data/initialProx.dat","rb")
         prox = pickle.load(pFile)
         pFile.close()
   
   if loadFinalCluster == 0:
      cluster,prox = swapAndSeek(X,Y,cluster,prox,sigLst)
      totProx = 0
      for p in prox:
         totProx = totProx + prox[p]
      print(' ')
      print('--------------------------------')
      print('The final clusters from seek and swap are')
      print(cluster)
      print('The poximity measures are')
      print(prox)
      print('The total proximity is '+str(totProx))
      print('--------------------------------')
      print(' ')
      graphDEAclusters(X,Y,cluster,sigLst,'./prostateFigs/finalClusters.png')
      pFile = open("./data/finalClusters.dat","wb")
      pickle.dump(cluster, pFile)
      pFile.close()
      pFile = open("./data/finalProx.dat","wb")
      pickle.dump(prox, pFile)
      pFile.close()
   #elif loadFinalCluster == 1:
   #   if os.path.isfile('./data/finalClusters.dat'):
   #      pFile = open("./data/finalClusters.dat","rb")
   #      cluster = pickle.load(pFile)
   #      pFile.close()
   #      graphDEAclusters(X,Y,cluster,sigLst,'./prostateFigs/finalClusters.png')
   #   if os.path.isfile('./data/finalProx.dat'):
   #      pFile = open("./data/finalProx.dat","rb")
   #      prox = pickle.load(pFile)
   #      pFile.close()
