from __future__ import division # safety with double division
from pyomo.environ import *
from pyomo.opt import SolverFactory
from pyomo.opt import SolverStatus, TerminationCondition
from uDEA import *
import math
import numpy as np
import copy
import itertools
import matplotlib
import matplotlib.pyplot as plt
import multiprocessing
import pickle

def clusterKMeansRestricted(crd, numMedians, szGrp, t):
   failStat = 1
   szGrpNp = np.array(szGrp)
   szGrpUnique = np.unique(szGrpNp)
   for i in range(len(crd)):
      crd[i] = [abs(j) for j in crd[i]]
   M = AbstractModel()
   M.n = RangeSet(0,len(crd)-1)
   M.u = RangeSet(0,len(szGrpUnique)-1)
   M.z = Var(M.n, M.n, within = Binary)
   M.w = Var(M.n, M.u, within = Binary)

   def calcMinDist(M):
      if t == '2norm':
         # 2 - norm
         return sum(sqrt(sum((crd[i][t]-crd[j][t])**2 for t in range(len(crd[0]))))*M.z[i,j] \
                    for i in M.n for j in M.n)
      elif t == '1norm':
         # 1 -norm
         return sum(sum(abs(crd[i][t]-crd[j][t]) for t in range(len(crd[0])))*M.z[i,j] \
                    for i in M.n for j in M.n)
      elif t == 'infnorm':
         # inf -norm
         return sum(max([abs(crd[i][t]-crd[j][t]) for t in range(len(crd[0]))])*M.z[i,j] \
                    for i in M.n for j in M.n)
      elif t == 'radial':
         # radial 
         return sum( abs( sqrt( sum(crd[i][t]**2 for t in range(len(crd[0]))) )\
                          - sqrt( sum(crd[j][t]**2 for t in range(len(crd[0]))) ) )*M.z[i,j] \
                    for i in M.n for j in M.n )
   M.minDist = Objective(rule=calcMinDist, sense=minimize)

   def ensureUniqueSz(M,j):
      return sum(M.w[j,k] for k in M.u) <= 1
   M.uniqueSzPerGpr = Constraint(M.n, rule=ensureUniqueSz)

   def ensureSzGrps(M,j):
      return sum(M.z[i,j] for i in M.n) == sum(szGrpUnique[k]*M.w[j,k] for k in M.u)
   M.szGrps = Constraint(M.n, rule=ensureSzGrps)

   def ensureSz(M,k):
      return sum(M.w[j,k] for j in M.n) == len(np.nonzero(szGrpNp == szGrpUnique[k])[0])
   M.selectSz = Constraint(M.u, rule=ensureSz)

   def calcMedians(M):
      return sum(M.z[i,i] for i in M.n) == numMedians
   M.medConst = Constraint(rule=calcMedians)

   def calcAssign(M,i):
      return sum(M.z[i,j] for j in M.n) == 1
   M.assignVert = Constraint(M.n, rule=calcAssign)

   def calcOnlyOne(M,i,j):
      if i == j:
         return Constraint.Skip
      else:
         return M.z[j,j] >= M.z[i,j]
   M.onlyOne = Constraint(M.n, M.n, rule=calcOnlyOne)

   # Create a problem instance
   instance = M.create_instance()
   
   # Indicate which solver to use
   #Opt = SolverFactory("glpk")
   Opt = SolverFactory("gurobi")
   
   # Set some reasonable parameters for solving
   #Opt.options['MIPGap'] = 0.01
   #Opt.options['TimeLimit'] = 20
   # For GLPK - mipgap doesn't seem to work
   #Opt.options['tmlim'] = 20
   #Opt.options['mipgap'] = 0.9
   
   # Generate a solution
   #Soln = Opt.solve(instance, tee=True)
   Soln = Opt.solve(instance)
   instance.solutions.load_from(Soln)
   
   # Print the output
   #print("Termination Condition was "+str(Soln.Solver.Termination_condition))
   #print(value(instance.minDist))
   #display(instance)
   grp = {}
   if str(Soln.Solver.Termination_condition) == "optimal":
      grpInd = [i for i in instance.n if value(instance.z[i,i]) > 0.9]
      k = 0
      for i in grpInd:
         grp[k] = [j for j in instance.n if value(instance.z[j,i]) > 0.9]
         k = k + 1
      totLen = 0
      for i in grp:
         totLen = totLen + len(grp[i])
      if totLen == sum(szGrp):
         failStat = 0
   return grp, failStat

def clusterKMeans(crd, numMedians, t):
   failStat = 1
   for i in range(len(crd)):
      crd[i] = [abs(j) for j in crd[i]]
   M = AbstractModel()
   M.n = RangeSet(0,len(crd)-1)
   M.z = Var(M.n, M.n, within = Binary)

   def calcMinDist(M):
      if t == '2norm':
         # 2 - norm
         return sum(sqrt(sum((crd[i][t]-crd[j][t])**2 for t in range(len(crd[0]))))*M.z[i,j] \
                    for i in M.n for j in M.n)
      elif t == '1norm':
         # 1 -norm
         return sum(sum(abs(crd[i][t]-crd[j][t]) for t in range(len(crd[0])))*M.z[i,j] \
                    for i in M.n for j in M.n)
      elif t == 'infnorm':
         # inf -norm
         return sum(max([abs(crd[i][t]-crd[j][t]) for t in range(len(crd[0]))])*M.z[i,j] \
                    for i in M.n for j in M.n)
      elif t == 'radial':
         # radial 
         return sum( abs( sqrt( sum(crd[i][t]**2 for t in range(len(crd[0]))) )\
                          - sqrt( sum(crd[j][t]**2 for t in range(len(crd[0]))) ) )*M.z[i,j] \
                    for i in M.n for j in M.n )
   M.minDist = Objective(rule=calcMinDist, sense=minimize)

   def calcMedians(M):
      return sum(M.z[i,i] for i in M.n) == numMedians
   M.medConst = Constraint(rule=calcMedians)

   def calcAssign(M,i):
      return sum(M.z[i,j] for j in M.n) == 1
   M.assignVert = Constraint(M.n, rule=calcAssign)

   def calcOnlyOne(M,i,j):
      if i == j:
         return Constraint.Skip
      else:
         return M.z[j,j] >= M.z[i,j]
   M.onlyOne = Constraint(M.n, M.n, rule=calcOnlyOne)

   # Create a problem instance
   instance = M.create_instance()
   
   # Indicate which solver to use
   #Opt = SolverFactory("glpk")
   Opt = SolverFactory("gurobi")
   
   # Set some reasonable parameters for solving
   #Opt.options['MIPGap'] = 0.01
   #Opt.options['TimeLimit'] = 20
   # For GLPK - mipgap doesn't seem to work
   #Opt.options['tmlim'] = 20
   #Opt.options['mipgap'] = 0.9
   
   # Generate a solution
   #Soln = Opt.solve(instance, tee=True)
   Soln = Opt.solve(instance)
   instance.solutions.load_from(Soln)
   
   # Print the output
   #print("Termination Condition was "+str(Soln.Solver.Termination_condition))
   #print(value(instance.minDist))
   grp = {}
   if str(Soln.Solver.Termination_condition) == "optimal":
      grpInd = [i for i in instance.n if value(instance.z[i,i]) > 0.9]
      k = 0
      for i in grpInd:
         grp[k] = [j for j in instance.n if value(instance.z[j,i]) > 0.9]
         k = k + 1
      totLen = 0
      for i in grp:
         totLen = totLen + len(grp[i])
      if totLen == len(crd[0]):
         failStat = 0
   return grp, failStat

def calcClusterProx(X,Y,cluster):
   prox = {}
   for c in cluster:
      RX = {}
      RY = {}
      RX[0] = []
      RY[0] = []
      for i in range(len(cluster[c])):
         RX[0].append([0 for j in range(len(cluster[c]))])
         RX[0][i][i] = 1
         RY[0].append([0 for j in range(len(cluster[c]))])
         RY[0][i][i] = 1
   
      calcProximityVal, minSigma, stat, proxLowBnd, proxUpBnd, sigLst = \
         proximityToEquitableEfficiency( \
            [[X[0][i] for i in cluster[c]]], [[Y[0][i] for i in cluster[c]]], \
            RX, RY)
      #print(sigLst)
      prox[c] = calcProximityVal
   
   return prox

def swapAndSeek(X,Y,cluster,prox,sigLst):
   #multiprocessing.set_start_method("spawn")  # try to keep things from hanging
   print(' ')
   print('Starting one iteration of the primary search')
   print(' ')
   itrCnt = 1
   ContinueSrch = 1
   while ContinueSrch == 1:
      foundImprovement = 0
      p = multiprocessing.Pool(10)
      proxOutcomes = p.starmap(parSwapAndSeek, \
                     [ [X,Y,prox,cluster,c] for c in itertools.product(cluster,cluster) \
                                            if c[0] != c[1] ])
      p.close()
      p.join()
      for r in proxOutcomes:
         tcluster = r[0]
         tprox = r[1]
         if sum([tprox[i] for i in tprox]) < sum([prox[i] for i in prox]):
            cluster = copy.deepcopy(tcluster)
            prox = copy.deepcopy(tprox)
            foundImprovement = 1
      if foundImprovement == 0:
         print('------- iteration '+str(itrCnt))
         print('------- found no improvement, stopping')
         ContinueSrch = 0
      else:
         graphDEAclusters(X,Y,cluster,sigLst,\
                          './prostateFigs/improved_'+str(itrCnt)+'.png')
         pFile = open("./data/intermediateClusters_"+str(itrCnt)+".dat","wb")
         pickle.dump(cluster,pFile)
         pFile.close()
         pFile = open("./data/intermediateProx_"+str(itrCnt)+".dat","wb")
         pickle.dump(prox,pFile)
         pFile.close() 
         totProx = 0
         for p in prox:
            totProx = totProx + prox[p]
         print('------- iteration '+str(itrCnt))
         print('------- found improvement, continuing')
         print('--------------------------------')
         print('The intermediate clusters are')
         print(cluster)
         print('The poximity measures are')
         print(prox)
         print('The total proximity is '+str(totProx))
         print('--------------------------------')
         print(' ')

      itrCnt = itrCnt+1

   return cluster, prox

def parSwapAndSeek(X,Y,prox,cluster,c):
   bstClst = copy.deepcopy(cluster)
   bstProx = copy.deepcopy(prox)
   k = 1
   for j in cluster[c[0]]:
      tmpClstA = [i for i in cluster[c[0]] if i != j]
      tmpClstB = [i for i in cluster[c[1]]]
      tmpClstB.append(j)
      tProx = calcClusterProx(X,Y,{0:tmpClstA,1:tmpClstB})
      tmpProx = copy.deepcopy(prox)
      tmpProx[c[0]] = tProx[0]
      tmpProx[c[1]] = tProx[1]
      print('\t'+str(j)+' in '+str(c[0])+' -> '+ str(c[1])+': '+str(k)+\
            '/'+str(len(cluster[c[0]]))+': prox = '+str(sum([tmpProx[i] for i in tmpProx])))
      #print({0:tmpClstA,1:tmpClstB})
      #print(tmpProx)
      #print(sum([tmpProx[i] for i in tmpProx]))
      k = k + 1
      if sum([tmpProx[i] for i in tmpProx]) < sum([bstProx[i] for i in bstProx]):
         bstClst = copy.deepcopy(cluster)
         bstClst[c[0]] = [i for i in tmpClstA]
         bstClst[c[1]] = [i for i in tmpClstB]
         bstProx = copy.deepcopy(tmpProx)

   print('\t done placing cluster '+str(c[0])+' DMUs in cluster '+str(c[1]))

   return bstClst, bstProx

def graphDEAclusters(X,Y,cluster,sigLst,saveName):
   # order the clusters
   clusterVal = setClusterVals(sigLst,cluster)
   srtInd = sorted(clusterVal, key=clusterVal.get)
   plt.ioff()  # turn off interactive mode to save without showing
   fig = plt.figure()

   pltOpt = {0:'gs', 1:'bo', 2:'rd'}
   #pltOpt = {0:'g', 1:'r', 2:'k'}
   k = 0
   for c in cluster:
      for i in cluster[c]:
         plt.plot(X[0][i], Y[0][i], pltOpt[srtInd[k]], markersize=12)
         #plt.plot(X[0][i], Y[0][i], '.', markersize=1)
         #plt.text(X[0][i], Y[0][i], str(i))
      k = k + 1
   plt.xticks(fontsize=14)
   plt.yticks(fontsize=14)
   plt.xlabel('Rectal gEUD (Gy)', fontsize=18)
   plt.ylabel('D95 PTV (Gy)', fontsize=18)
   #plt.xlabel('Semi-Deviation', fontsize=18)
   #plt.ylabel('Average Return (ROI)', fontsize=18)
   plt.savefig(saveName,bbox_inches='tight')
   #plt.show()
   plt.close(fig)

def setClusterVals(sigLst, cluster):
   clusterVal = {}
   for c in cluster:
      clusterVal[c] = sum( sqrt( sum(sigLst[i][t]**2 for t in range(len(sigLst[0]))) ) \
                          for i in cluster[c]) / len(cluster[c])
   return clusterVal


def srchForInitialClusters(X, Y, sigLst, numClstrs):
   #multiprocessing.set_start_method("spawn")  # try to keep things from hanging
   n = len(X[0])
   p = multiprocessing.Pool(10)
   print("searching for initial cluster sizes:")
   kClstr = p.starmap(parSrchForInitialClusters, \
                      [ [X, Y, sigLst, numClstrs, i] \
                        for i in range(2, math.floor(n/numClstrs)+1)] )
   p.close()
   p.join()
   # find the best cluster
   minProx = float('inf') 
   for c in kClstr:
      for i in c:
         prox = c[i]['prox']
         cluster = c[i]['cluster']
         totProx = 0
         for p in prox:
            totProx = totProx + prox[p]
         if totProx < minProx:
            minProx = totProx
            bstProx = copy.deepcopy(prox)
            bstClstr = copy.deepcopy(cluster)
   # we are done
   return bstClstr, bstProx

def parSrchForInitialClusters(X, Y, sigLst, numClstrs, i):
   #tactic = {0: 'radial', 1: '1norm', 2:'2norm', 3:'infnorm'}
   #tactic = {0: 'radial', 1:'2norm'}
   n = len(X[0])
   results = {}
   minProx = float('inf') 
   for j in range(2,n-i-2):
      k = n-i-j
      if i <= j and j <= k:
         cluster,failStat = clusterKMeansRestricted(sigLst,numClstrs,[i,j,k],'radial')
         if failStat == 0:
            prox = calcClusterProx(X,Y,cluster)
            totProx = 0
            for p in prox:
               totProx = totProx + prox[p]
            print("\t("+str(i)+","+str(j)+","+str(k)+") totProx is "+str(totProx))
            if totProx < minProx:
               minProx = totProx
               bstProx = copy.deepcopy(prox)
               bstClstr = copy.deepcopy(cluster) 
               results[i] = {'prox':bstProx, 'cluster':bstClstr}
         elif failStat != 0:
            print(' ')
            print('ERROR: K-means failed')
            print(' ')

   return results


